#!/bin/bash

V_NAME="Shell Scripting is Fun!"
echo "$V_NAME"