#!/bin/bash

VARIABLE_NAME="Hostname"
echo "This is my $VARIABLE_NAME"

