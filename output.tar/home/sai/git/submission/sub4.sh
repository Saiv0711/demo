#!/bin/bash

for Animals in man bear pig dog cat sheep
do
    echo "Animals: $Animals"
done